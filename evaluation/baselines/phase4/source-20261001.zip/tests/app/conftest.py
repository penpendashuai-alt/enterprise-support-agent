from unittest.mock import AsyncMock, patch

import pytest
import streamlit as st

from schema import AgentInfo, ServiceMetadata
from schema.models import OpenAIModelName


@pytest.fixture(autouse=True)
def stable_toolbar_mode():
    # AppTest can time out on the app's initial configuration-only st.rerun().
    original = st.get_option("client.toolbarMode")
    st.set_option("client.toolbarMode", "minimal")
    yield
    st.set_option("client.toolbarMode", original)


@pytest.fixture
def mock_agent_client(mock_env):
    """Fixture for creating a mock AgentClient with a clean environment."""

    mock_info = ServiceMetadata(
        default_agent="test-agent",
        agents=[
            AgentInfo(key="test-agent", description="Test agent"),
            AgentInfo(key="chatbot", description="Chatbot"),
        ],
        default_model=OpenAIModelName.GPT_5_NANO,
        models=[OpenAIModelName.GPT_5_NANO, OpenAIModelName.GPT_5_MINI],
    )

    with (
        patch("client.AgentClient") as mock_agent_client,
        patch("voice.VoiceManager.from_env", return_value=None),
    ):
        mock_agent_client_instance = mock_agent_client.return_value
        mock_agent_client_instance.info = mock_info
        # Give the mock a deterministic selected agent.
        mock_agent_client_instance.agent = "test-agent"
        mock_agent_client_instance.aget_pending_approval = AsyncMock(return_value=None)
        yield mock_agent_client_instance
